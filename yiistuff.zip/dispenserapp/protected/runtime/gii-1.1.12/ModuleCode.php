<?php
return array (
  'template' => 'default',
);
