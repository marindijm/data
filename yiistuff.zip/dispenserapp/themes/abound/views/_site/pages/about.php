<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name . ' - Grid';
$this->breadcrumbs=array(
	'Grid',
);
?>
<h1>Grid</h1>

<div class="row-fluid">
	<div class="span12 well">
	  <h3>Heading</h3>
	  <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
	  <p><a class="btn" href="#">View details &raquo;</a></p>
	</div><!--/span-->
</div><!--/row-->

<div class="row-fluid">
	<div class="span6 well">
	  <h3>Heading</h3>
	  <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
	  <p><a class="btn" href="#">View details &raquo;</a></p>
	</div><!--/span-->
	<div class="span6 well">
	  <h3>Heading</h3>
	  <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
	  <p><a class="btn" href="#">View details &raquo;</a></p>
	</div><!--/span-->
</div><!--/row-->

<div class="row-fluid">
	<div class="span4 well">
	  <h3>Heading</h3>
	  <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
	  <p><a class="btn" href="#">View details &raquo;</a></p>
	</div><!--/span-->
	<div class="span4 well">
	  <h3>Heading</h3>
	  <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
	  <p><a class="btn" href="#">View details &raquo;</a></p>
	</div><!--/span-->
	<div class="span4 well">
	  <h3>Heading</h3>
	  <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
	  <p><a class="btn" href="#">View details &raquo;</a></p>
	</div><!--/span-->
</div><!--/row-->

<div class="row-fluid">
	<div class="span3 well">
	  <h3>Heading</h3>
	  <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
	  <p><a class="btn" href="#">View details &raquo;</a></p>
	</div><!--/span-->
	<div class="span3 well">
	  <h3>Heading</h3>
	  <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
	  <p><a class="btn" href="#">View details &raquo;</a></p>
	</div><!--/span-->
	<div class="span3 well">
	  <h3>Heading</h3>
	  <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
	  <p><a class="btn" href="#">View details &raquo;</a></p>
	</div><!--/span-->
	<div class="span3 well">
	  <h3>Heading</h3>
	  <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
	  <p><a class="btn" href="#">View details &raquo;</a></p>
	</div><!--/span-->
</div><!--/row-->

<div class="row-fluid">
	<div class="span8 well">
	  <h3>Heading</h3>
	  <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
	  <p><a class="btn" href="#">View details &raquo;</a></p>
	</div><!--/span-->
	<div class="span4 well">
	  <h3>Heading</h3>
	  <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
	  <p><a class="btn" href="#">View details &raquo;</a></p>
	</div><!--/span-->
</div><!--/row-->

<div class="row-fluid">
	<div class="span4 well">
	  <h3>Heading</h3>
	  <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
	  <p><a class="btn" href="#">View details &raquo;</a></p>
	</div><!--/span-->
	<div class="span4 well">
	  <h3>Heading</h3>
	  <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
	  <p><a class="btn" href="#">View details &raquo;</a></p>
	</div><!--/span-->
	<div class="span4 well">
	  <h3>Heading</h3>
	  <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
	  <p><a class="btn" href="#">View details &raquo;</a></p>
	</div><!--/span-->
</div><!--/row-->

<div class="row-fluid">
	<div class="span10 well">
	  <h3>Heading</h3>
	  <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
	  <p><a class="btn" href="#">View details &raquo;</a></p>
	</div><!--/span-->
	<div class="span2 well">
	  <h3>Heading</h3>
	  <p>Donec id elit non mi porta gravida at eget. </p>
	  <p><a class="btn" href="#">View details &raquo;</a></p>
	</div><!--/span-->
</div><!--/row-->

<div class="row-fluid">
	<div class="span3 well">
	  <h3>Heading</h3>
	  <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
	  <p><a class="btn" href="#">View details &raquo;</a></p>
	</div><!--/span-->
	<div class="span4 well">
	  <h3>Heading</h3>
	  <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
	  <p><a class="btn" href="#">View details &raquo;</a></p>
	</div><!--/span-->
	<div class="span5 well">
	  <h3>Heading</h3>
	  <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
	  <p><a class="btn" href="#">View details &raquo;</a></p>
	</div><!--/span-->
</div><!--/row-->