<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

$this->menu=array(
	array('label'=>'List Issue', 'url'=>array('index')),
	array('label'=>'Create Issue', 'url'=>array('create')),
	array('label'=>'Manage Issue', 'url'=>array('admin')),
);

?>
